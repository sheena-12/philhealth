# Panimula CSS
Base sass and html files for any project

using gulpfile by Nick 

- Run gulp watch from terminal to compile your stylesheet
- Files should live w/in /web